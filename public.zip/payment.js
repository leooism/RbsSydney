
const creditCard = document.querySelector('#card');
const cardInput = document.querySelector('#card__input')
const payPal = document.querySelector('#paypal');

const cardHolder = document.querySelector('#cardholder');
const date = document.querySelector('#date');
const password = document.querySelector('#verification');
const cardNumber = document.querySelector('#cardnumber');
const legalServices = document.querySelector('#legal');
const legalServicesOption = document.querySelector('.legal__services');
const panelBody1 = document.querySelector('#panelBody1')
const panelBody2 = document.querySelector('#panelBody2')
const panelBody3 = document.querySelector('#panelBody3')
const panelBody4 = document.querySelector('#panelBody4')
const agent = document.querySelector('#agent');
const legal_Services = document.querySelector('#legal');
const agentRefrenceNumber = document.querySelector('.agent__refrenceNumber');
const legalServicesOptions = document.querySelector('.legalService__options');
var legalService;
const servicesContainer = document.querySelector('.services__container')
const options = document.querySelector('.options');
var text;
var back;
const panelFoot = document.querySelector('.panel-footer');
var panel1 = true;

back = document.createElement('button');
var Next = document.createElement('button');
function confirm(){
    panelBody1.style.display = 'none';
    panelBody2.style.display = 'block';
    document.querySelector('#step1').classList.add('active')
    if(panelBody2.style.display === 'block'){
        panelFoot.innerHTML = '';
       

        Next.textContent = 'Next';
        Next.classList.add('btn', 'next-btn');
        Next.style.display = 'none';
        back.textContent = "Back"
        back.classList.add('btn', 'back-btn');
        panelFoot.appendChild(back);
        panelFoot.appendChild(Next)
        
        const agree = document.getElementById('agree');
        agree.addEventListener('click', function(){
          Next.style.display = 'block';
   
        })  
        payment(Next)
   
    }

}
    function payment(Next){
    Next.addEventListener('click', function(){
        Next.style.display = 'none';
        document.querySelector('#step2').classList.add('active')
        panelBody2.style.display = 'none';
        panelBody3.style.display = 'block';
        creditCard.addEventListener('click', function()  {
            if (this.checked){
                cardInput.style.display = "flex";
                cardInput.style.transition = "all .4s linear";
          this.parentNode.parentNode.parentNode.style.marginTop = '-90px';
          this.parentNode.parentNode.parentNode.style.transition = 'all .4s linear';
        Next.style.display = 'block'
        }
        })
            payPal.addEventListener('click', function(){
                Next.style.display = 'block';
        
            this.checked ? cardInput.style.display = 'none': 'block'    
            })
        
        //Form validation
        
        function warning(el){
            el.style.border ='1px solid red';
            setTimeout((el) => el.style.border = "", 3000, el)
        }
        function Validation(items, event){
            
        
             items.forEach(item => {
           if (item.value === ""){
                    warning(item);
             }}) }
        Next.addEventListener('click', function(e) {
            this.style.display = 'block';
            
            Validation([cardHolder, date, password, cardNumber]);
            // if(this.parentNode.parentNode.ParentNode)

            if(this.parentNode.parentNode.childNodes[7].id === 'panelBody3'){
            Next.onclick = () => {
                panelBody3.style.display = 'none';
                panelBody4.style.display = 'block';
                document.querySelector('#step3').classList.add('active')
                panelFoot.remove();
            }
        }
           
            
        })


    });
    back.onclick = () =>{
        panelBody3.style.display = 'none';
        panelBody2.style.display = 'block';
    }
}


//CHeck whether the button is checked or not if checked then display the hidden container
(function agentS(fnc){
    if (panel1){
        const a = document.createElement('a');
        const button = document.createElement('button');
        button.classList.add('btn')
        button.classList.add('legalService')
        button.innerHTML  = '<a id = "text" href="#">Pay for legal Services</a>';
        a.innerHTML = '<button class="btn next-btn">Next</button>';
        
        panelFoot.appendChild(a);
        panelFoot.appendChild(button);
        next = document.querySelector('.next-btn');
        text = document.querySelector('#text');
        legalService = document.querySelector('.legalService')
                agent.addEventListener('click', function(){
                  options.style.display = 'none';
                  agentRefrenceNumber.style.display = 'block';
                legalService.style.display = 'block';
            
              
            })
            legal_Services.addEventListener('click',function(){
            legalServicesOptions.style.display = 'flex';
            options.style.display = 'none';
            text.textContent = "Pay to agent";
            legalService.style.display = 'block';
            
            })
           
            legalService.addEventListener('click', function (){
            agentRefrenceNumber.style.display = 'none';
            legalServicesOptions.style.display = 'flex';
            if(text.textContent.includes('agent')){
              text.textContent = "Pay for legal services"
              agentRefrenceNumber.style.display = 'block';
            legalServicesOptions.style.display = 'none'
            }else{
            text.textContent = "Pay to agent"
            }
            })
        
        }
        fnc(next)
})(nexT);
function nexT(next) {
    next.addEventListener('click', function(){
        confirm();
        back.addEventListener('click', function(){
            const a = document.createElement('a');
            const button = document.createElement('button');
            button.classList.add('btn')
            button.innerHTML  = '<a id = "text" href="#">Pay for legal Services</a>';
            a.innerHTML = '<button class="btn next-btn">Next</button>';
            panelFoot.appendChild(button);

            panelBody2.style.display = 'none';
            panelBody1.style.display = 'block';
            
            document.querySelector("#step1").classList.remove('active');
            panelFoot.innerHTML= "";
            panelFoot.appendChild(a);
            a.onclick = () => confirm()
    })    
    })
}





